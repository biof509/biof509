The workflow is as follows:

1. Run generate_swarm.py - This generates swarm.file with a leave one out cross-validation strategy
2. Pass swarm.file to the swarm command on biowulf, specifying the resources we need (GPU)
3. Resources are allocated and each line in swarm.file is executed on a dedicated node.
4. fs_based_model.sh configures the environment and creates links to our training data.
5. fs_based.model.py is run by fs_based_model.sh and trains the model. The weights are saved at the end of each epoch if the model has improved.


Although not included in the files here, the next step is to apply the best model. This is done by loading the weights back into the model and then applying it on new images.