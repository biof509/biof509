#!/bin/bash
#
# ./fs_based_model <working_directory> <validation_hash>

echo $2

# Setup environment
module load python/3.5
source activate personal-py
module load CUDA/7.5
module load cuDNN/5.0.5
export LD_LIBRARY_PATH=/usr/local/apps/openslide/3.4.1/lib:$LD_LIBRARY_PATH

# Arrange files in train/validation folders using symbolic links
# Make directories
mkdir $1/$2
mkdir $1/$2/{train,validation}
mkdir $1/$2/train/{positive,negative}
mkdir $1/$2/validation/{positive,negative}
# Link all images
ln -s -t $1/$2/train/positive /data/streetj/WSI_1_preprocessed/positive/*
ln -s -t $1/$2/train/negative /data/streetj/WSI_1_preprocessed/negative/*
# Remove validation images
rm $1/$2/train/positive/$2*
rm $1/$2/train/negative/$2*
# Link validation images
for i in /data/streetj/WSI_1_preprocessed/positive/$2*; do
    ln -s -t $1/$2/validation/positive $i
done
for i in /data/streetj/WSI_1_preprocessed/negative/$2*; do
    ln -s -t $1/$2/validation/negative $i
done

# Call python script to train model
export THEANO_FLAGS=mode=FAST_RUN,device=gpu,floatX=float32,force_device=True,base_compiledir=$1/$2

python fs_based_model.py $1/$2
