import os
import click

slides = {'11_26609_000_014_L01 HE.svs': '8ac88de391cb6962df7d351558f5a95e2fdbd05943e9e1d8715d7db1df9b5164',
'10-26609-009-003.L2 HE.svs': '2bc02cc00fa5af349d707ca586b98690b2d685453e174457af807956cf60e763',
'11_26609_000_011_L01_HE.svs': '747929811b752903e63b27e92bdb37cd2e6ff736f7c57d2e17e59111daf013d0',
'11_26609_001_004 L6 HE.ndpi': '282ae5631cfd25fcace0717298729e83310715e65ef1c7dcfd15383921e93f68',
'11_26609_001_003 L1 HE.ndpi': '181ff47bbda11fa679603faca50e624ae018f6c5ce134326e37a3a21d2ca7875',
'10-26609-022-002 L5 HE.svs': '7ed8869f4efe50b82643835217ea890c386ecbb8e2fc300d9b8b0367bd1bccd2',
'12_26609_001_009 L01 HE.ndpi': 'dba7104175d11b4f8b8925b069ec3388c7250e03ee6eb21422c8306ba5840514',
'13_26609_007_001 L04 HE.ndpi': '2a383417dd312f774548577cffe3000501e766f2e2f92d7ed9f8bdce258e81f0',
'12_26609_024_023 L2 HE.ndpi': '0db0c5b76fcb7556db54808526b7a53a8373589db29e673701a4bd06e99d6319',
'10-26609-009-001.L5.svs': 'b42fb2471ae81924295842aa1f37c15e84f7c3e096acfd9dad7418f195356542',
'10-26609-009-002.L2 HE.svs': '963f971fdf33b8d21dc2033e08e4180260e365fab5252b82c74fc1181e6e6096',
'11_26609_000_012_L01 HE.svs': '989988e1c1d2eade7073afc4edda61f3b710cb1c302422faf8a0b092dca4b32a',
'11_26609_001_005 L6 HE.ndpi': '4b7c6a9c0f0c4d1cdb3e4990e707a8184ce38d6051996080574466b3a1d8d324',
'10_26609_001_002 L6 HE.ndpi': '702fa20f59eb63f9a08a711185051e062b67a9444a74bd22044ef6489e8566f7'}

@click.command()
@click.argument('swarm_file')
@click.argument('working_directory')
def run(swarm_file, working_directory):
    keys = list(slides.keys())
    with open(swarm_file, 'w') as f:
        for k in keys:
            line = '/home/streetj/model2/fs_based_model.sh {0} {1}\n'.format(working_directory, slides[k][:8])
            f.write(line)
    

if __name__ == '__main__':
    run()
