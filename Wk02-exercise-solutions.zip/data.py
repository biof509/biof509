import numpy as np
import random

def semicircle(num_points=50, radius=1):
    """Gneerates a path with points placed on a semicircle
    
    Arguments:
    num_points -- The number of points in the path
    radius -- The radius of the semicircle
    
    Returns: List of points
    """
    a = np.linspace(-np.pi/2, np.pi/2, num_points)
    x = radius * np.cos(a)
    y = radius * np.sin(a)
    coords = [(i,j) for i,j in zip(x,y)]
    random.shuffle(coords)
    return coords
    
def random_coords(num_points=50):
    """Generates a path with randomly placed points
    
    Arguments:
    num_points -- The number of points in the path
    
    Returns: List of points
    """
    coords = []
    for i in range(num_points):
        coords.append((random.random(), random.random()))
    return coords