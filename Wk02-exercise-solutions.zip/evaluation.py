import matplotlib.pyplot as plt


def distance(coords):
    """Calculates the distance for a path

    Arguments:
    coords -- A list of coordinates, i.e. [(0,0), (1,1)]

    Returns: The distance
    """
    distance = 0
    for p1, p2 in zip(coords[:-1], coords[1:]):
        distance += ((p2[0] - p1[0]) ** 2 + (p2[1] - p1[1]) ** 2) ** 0.5
    return distance


def compare_optimization(coords, optimization_functions, target=None):
    """Utility function to run multiple optimization functions and
        plot their performance

    Arguments:
    coords -- A list of coordinates, i.e. [(0,0), (1,1)]
    optimization_functions -- List of options to evaluate.
        Each stored as a dictionary with func, func_params, label
    target -- The actual shortest distance for the path

    Returns:
    all_results -- Results from each function including shortest path,
        distance, history, and the options used
    fig -- Matplotlib figure
    ax -- Matplotlib axes
    """
    fig, ax = plt.subplots(1, 2, figsize=(12, 6))
    if target:
        ax[0].axhline(target, linestyle='--', color='k')
    all_results = []
    for option in optimization_functions:
        path, cost, history = option['func'](coords, **option['func_params'])
        ax[0].plot([i['current_cost'] for i in history], label=option['label'])
        all_results.append({'path': path, 'cost': cost,
                            'history': history, 'option': option})
    paths = [i['path'] for i in all_results]
    paths.sort(key=lambda x: distance(x))
    best_path = paths[0]
    ax[1].plot([i[0] for i in best_path], [i[1] for i in best_path], 'bo-')
    ax[0].legend()
    return (all_results, fig, ax)
