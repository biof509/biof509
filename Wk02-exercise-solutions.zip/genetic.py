import random



def select_best(population, cost_func, num_to_keep):
    """Select the best candidate paths from a selection of paths

    Arguments:
    population -- list
        The candidate paths
    cost_func -- function
        The distance metric
    num_to_keep -- integer
        The number of paths to return

    Returns
    out -- list\n",
        The best paths
    """
    scored_population = [(i, cost_func(i)) for i in population]
    scored_population.sort(key=lambda x: x[1])
    return [i[0] for i in scored_population[:num_to_keep]]

    
def recombine(population):
    """Create a new path from a population of paths

    Two paths are selected and recombined together similar to meiosis

    Arguments:
    population -- list
        The candidate paths
        
    Returns:
    out -- list
        The new path
    """
    # Randomly choose two parents
    options = list(range(len(population)))
    random.shuffle(options)
    partner1 = options[0]
    partner2 = options[1]
    # Choose a split point, take the first parents order to that split point, 
    # then the second parents order for all remaining points
    split_point = random.randint(0, len(population[0])-1)
    child = population[partner1][:split_point]
    for point in population[partner2]:
        if point not in child:
            child.append(point)
    return child


def genetic_algorithm_optimizer(starting_path, cost_func, new_path_func, pop_size, generations, mutation_rate=1., recombine=recombine):
    """Identifies the shortest path through a collection of points using a genetic algorithm
    
    Arguments:
    starting_path -- A list of coordinates, i.e. [(0,0), (1,1)]
    cost_func -- function
        The distance metric
    new_path_func -- function
        Function to create a new path based on the one supplied
    pop_size -- integer
        Number of different paths created in each generation
    generations -- integer
        Number of rounds of optimization
    mutation_rate -- float
        Probability of introducing a mutation in each new path generated
    recombine -- function
        Function to generate a new path by combining two existing paths from the current population
        
    Returns:
    out : tuple
        The best path found, the distance of the best path, and a history
        of the step, temperature, and current distance of best path
    """
    # Create a starting population by randomly shuffling the points
    population = []
    for i in range(pop_size):
        new_path = starting_path[:]
        random.shuffle(new_path)
        population.append(new_path)
    history = []
    # Take the top 25% of routes and recombine to create new routes, repeating for generations
    for i in range(generations):
        pop_best = select_best(population, cost_func, int(pop_size / 4))
        new_population = []
        for i in range(pop_size):
            p = recombine(pop_best)
            if random.random() < mutation_rate:
                p = new_path_func(p)
            new_population.append(p)
        population = new_population
        best = select_best(population, cost_func, 1)
        record = {'generation':i, 'current_cost':cost_func(best[0]),}
        history.append(record)
    return (best[0], cost_func(best[0]), history)