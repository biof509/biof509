import numpy as np
import random


def simulated_annealing_optimizer(starting_path, cost_func, new_path_func,
                                start_temp, min_temp, steps):
    """Identifies the shortest path through a collection of points using
        a simulated annealing algorithm

    Arguments:
    starting_path -- A list of coordinates, i.e. [(0,0), (1,1)]
    cost_func -- function
        The distance metric
    new_path_func -- function
        Function to create a new path based on the one supplied
    start_temp -- float
        Likelihood of accepting a worse path at the beginning of
        the optimization
    min_temp -- float
        Likelihood of accepting a worse path at the end of optimization
    steps -- integer
        The number of round of optimization

    Returns:
    out : tuple
        The best path found, the distance of the best path, and a history
        of the step, temperature, and current distance of best path
    """
    current_path = starting_path[:]
    current_cost = cost_func(current_path)
    temp_factor = -np.log(start_temp / min_temp)
    history = []
    for s in range(0, steps):
        temp = start_temp * np.exp(temp_factor * s / steps)
        new_path = new_path_func(current_path)
        new_cost = cost_func(new_path)
        if (new_cost < current_cost) or \
                (random.random() <= np.exp(-(new_cost - current_cost)/temp)):
            current_path = new_path
            current_cost = new_cost
        record = {'step': s, 'temperature': temp,
                    'current_cost': current_cost, }
        history.append(record)
    return (current_path, current_cost, history)
