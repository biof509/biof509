"""A GUI application to support labeling of glomeruli in whole slide images"""


from display import Display





if __name__ == "__main__":
    d = Display()
    d.mainloop()
